import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import ListComponent from './components/list-component';
import AddItemComponent from './components/add.item-component';

const App = props => {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/list" element={<ListComponent />} />
          <Route path="/add-item" element={<AddItemComponent />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
