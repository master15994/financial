import React, { useState } from 'react';
import { Input, Select, Space, InputNumber, Button } from 'antd';
import { useForm } from 'react-hook-form';

const AddItemComponent = () => {
  const [transactions, setTransactions] = useState([]);
  const [newTransaction, setNewTransaction] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const addTransaction = () => {
    setTransactions([...transactions, newTransaction]);
    setNewTransaction('');
  };

  const options = [
    { label: 'Доход', value: 'income' },
    { label: 'Расход', value: 'consumption' },
  ];

  return (
    <form onSubmit={handleSubmit(data => console.log(data))}>
      <Input {...register('description')} placeholder="Описание" />
      <InputNumber {...register('sum')} min={1} defaultValue={1} />
      <Space wrap>
        <Select
          {...register('income')}
          defaultValue="income"
          style={{ width: 120 }}
          options={options}
        />
      </Space>
      <Button htmlType="submit" type="primary">
        Primary Button
      </Button>
    </form>
  );
};

export default AddItemComponent;
